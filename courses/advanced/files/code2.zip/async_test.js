const funcA = () => new Promise((resolve) => {
    const result = 1 + 2
    resolve(result)
})

console.log(funcA()) // Promiseオブジェクト
funcA().then((value) => {
    console.log(value)
})

// funcAとfuncBは同値

const funcB = async () => {
    const result = 1 + 2
    return result
}

console.log(funcB())

funcB().then((value) => {
    console.log(value)
})

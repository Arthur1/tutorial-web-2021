const axios = require('axios')

const url = 'http://s3-ap-northeast-1.amazonaws.com/titechapp-web-data/news.json'

const main = async () => {
    const response = await axios.get(url)
    console.log(response.data)
}

main()

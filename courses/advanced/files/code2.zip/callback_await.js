const wait1s = () => new Promise((resolve) => {
    setTimeout(() => {
        resolve()
    }, 1000)
})

const main = async () => {
    await wait1s()
    console.log('A')

    await wait1s()
    console.log('B')

    await wait1s()
    console.log('C')
}

main()

/*
setTimeout(() => {
    console.log('A')
    setTimeout(() => {
        console.log('B')
        setTimeout(() => {
          console.log('C')
        }, 1000)
    }, 1000)
}, 1000)
*/

// 以下のコードはNG
// AとBとCはほぼ同時に出力される
// また、順番を保証できない

setTimeout(() => {
    console.log('A')
}, 1000)

setTimeout(() => {
    console.log('B')
}, 1000)

setTimeout(() => {
    console.log('C')
}, 1000)

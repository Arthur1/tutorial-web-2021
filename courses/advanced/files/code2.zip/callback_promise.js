const wait1s = () => new Promise((callback) => {
    setTimeout(() => {
      callback()
    }, 1000)
  })

wait1s().then(() => {
    console.log('A')
    return wait1s()
}).then(() => {
    console.log('B')
    return wait1s()
}).then(() => {
    console.log('C')
})

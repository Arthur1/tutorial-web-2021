module.exports = {
    hello() {
        console.log('Hello.')
    },

    goodMorning() {
        console.log('Good morning.')
    },
}

const greeting = require('./commonjs_greeting.js')

greeting.hello()

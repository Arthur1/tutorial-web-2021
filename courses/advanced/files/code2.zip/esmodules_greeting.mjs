export default {
    hello() {
        console.log('Hello.')
    },

    goodMorning() {
        console.log('Good morning.')
    },
}

import greeting from './esmodules_greeting.mjs'

greeting.hello()

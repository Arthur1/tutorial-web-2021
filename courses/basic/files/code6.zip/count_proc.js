// Now I need a drink, alcoholic of course,
// after the heavy lectures involving quantum mechanics.
var words = [
    'Now', 'I', 'need', 'a', 'drink',
    'alcoholic', 'of', 'course',
    'after', 'the', 'heavy', 'lectures',
    'involving', 'quantum', 'mechanics',
];

var count = 0;
for (var i = 0; i < words.length; i++) {
    count += words[i].length;
}

console.log(count);

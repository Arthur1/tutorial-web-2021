var message = 'Hello, world!';
var length = message.length;
for (var i = 0; i < length; i++) {
  console.log(message[i]);
}

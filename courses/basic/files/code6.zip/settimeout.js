console.log('A');

setTimeout(function() {
    console.log('B');
}, 1000);

console.log('C');

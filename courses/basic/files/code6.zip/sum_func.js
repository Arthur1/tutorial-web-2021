// Now I need a drink, alcoholic of course,
// after the heavy lectures involving quantum mechanics.
var words = [
    'Now', 'I', 'need', 'a', 'drink',
    'alcoholic', 'of', 'course',
    'after', 'the', 'heavy', 'lectures',
    'involving', 'quantum', 'mechanics',
];

var count = words.map(function(word) {
    return word.length;
}).reduce(function(acc, cur) {
    return acc + cur;
});

// ES2015なら
// var count = words.map((word) => word.length)
//     .reduce((acc, cur) => acc + cur)

console.log(count);

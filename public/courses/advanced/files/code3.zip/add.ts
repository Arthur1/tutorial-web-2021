namespace add {
    const add = (a: number, b: number): number => {
        return a + b
    }
    
    let result: number = add(3, 4)
    console.log(result)
}

namespace fruits {
    const fruits: string[] = []

    fruits.push('apple')
    fruits.push('orange')
    // fruits.push(4)

    console.log(fruits)
}

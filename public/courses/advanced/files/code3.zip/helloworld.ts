namespace helloworld {
    let message: string
    message = 'Hello, World!'

    console.log(message)
}

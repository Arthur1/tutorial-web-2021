namespace person {
    interface Person {
        name: string
        age: number
        greets(): void
    }
    
    interface Student extends Person {
        id: string
    }

    const arthur: Student = {
        name: 'Arthur',
        age: 24,
        id: '15_12345',
        greets() {
            console.log(`Hello, I'm ${this.name}.`)
        }
    }

    arthur.greets()
}

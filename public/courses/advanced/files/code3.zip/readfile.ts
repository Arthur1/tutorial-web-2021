import fs from 'fs/promises'

namespace readfile {
    const main = async () => {
        const result = await fs.readFile('./.node-version', 'utf-8')
        console.log(result)
    }
    main()
}

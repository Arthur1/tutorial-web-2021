namespace shape {
    interface Square {
        type: 'Square'
        size: number
    }
    interface Rectangle {
        type: 'Rectangle'
        width: number
        height: number
    }
    interface Circle {
        type: 'Circle'
        radius: number
    }
    type Shape = Square | Rectangle | Circle

    const getArea = (s: Shape) => {
        if (s.type === 'Square') {
            return s.size * s.size
        } else if (s.type === 'Rectangle') {
            return s.width * s.height
        } else if (s.type === 'Circle') {
            return s.radius * s.radius * 3
        } else {
            const _err: never = s
        }
    }

    /*
    const rect: Rectangle = {
        type: 'Rectangle',
        width: 4,
        height: 3,
    }
    console.log(getArea(rect))
    */
    
    const circle: Circle = {
       type: 'Circle',
       radius: 1,
    }
    console.log(getArea(circle))
}

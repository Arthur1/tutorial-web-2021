namespace union {
    const value: string | number = 'hello'

    console.log(value)

    /*
    const getLength = (value: string | number): number => {
        return value.length
    }
    console.log(getLength(value))
    */
}

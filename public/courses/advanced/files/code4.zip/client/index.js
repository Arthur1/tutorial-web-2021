const axios = require('axios');

const HOST = 'http://localhost:3000'

// GET /api/articles
// 記事のリストの取得
const main = async () => {
  const response = await axios.get(`${HOST}/api/articles`)
  console.log(response.status)
  console.log(response.data)
}

/*
// GET /api/articles/:id
// 記事の取得
const main = async () => {
  const response = await axios.get(`${HOST}/api/articles/1`)
  console.log(response.status)
  console.log(response.data)
}
*/

/*
// POST /api/articles
// 記事の追加
const main = async () => {
  const payload = {
    title: 'テスト投稿です',
    body: 'こんにちは！',
  }
  const response = await axios.post(`${HOST}/api/articles`, payload)
  console.log(response.status)
  console.log(response.data)
  console.log('-----------------')

  const response2 = await axios.get(`${HOST}/api/articles`)
  console.log(response2.status)
  console.log(response2.data)
}
*/

/*
// PUT /api/articles/:id
// 記事の編集
const main = async () => {
  const payload = {
    title: 'Hello, world!',
    body: '編集ができていることを確認',
  }
  const response = await axios.put(`${HOST}/api/articles/1`, payload)
  console.log(response.status)
  console.log(response.data)
  console.log('-----------------')

  const response2 = await axios.get(`${HOST}/api/articles/1`)
  console.log(response2.status)
  console.log(response2.data)
}
*/

/*
// DELETE /api/articles/:id
// 記事の削除
const main = async () => {
  try {
    const response = await axios.delete(`${HOST}/api/articles/2`)
    console.log(response.status)
    console.log(response.data)
  } catch (error) {
    console.log(error.response.status)
    console.log(error.response.data)
  }
  console.log('-----------------')

  const response2 = await axios.get(`${HOST}/api/articles`)
  console.log(response2.status)
  console.log(response2.data)
}
*/

main()

import express from "express";

interface Article {
  id: number;
  title: string;
  body: string;
}

const app = express();

app.use(express.json());

const articles: Article[] = [
  {
    id: 1,
    title: "Hello, world!",
    body: "こんにちは、世界！\nこれはREST APIのサンプルです。",
  },
  {
    id: 2,
    title: "イーハトーヴォ",
    body: "あのイーハトーヴォのすきとほった風、夏でも底に冷たさをもつ青いそら、うつくしい森で飾られたモーリオ市、郊外のぎらぎらひかる草の波",
  },
];

app.get("/", (_, response) => {
  response.send("SAMPLE REST API");
});

/**
 * GET /api/articles
 * 記事の一覧を取得
 */
app.get("/api/articles", (_, response) => {
  response.send(articles);
});

/**
 * GET /api/articles/:id
 * 指定したidの記事を取得
 */
app.get("/api/articles/:id", (request, response) => {
  const article = articles.find(
    (article) => article.id === parseInt(request.params.id)
  );
  if (!article) return response.status(404).send("Article not found.");
  response.send(article);
});

/**
 * POST /api/articles
 * 記事を作成
 */
app.post("/api/articles", (request, response) => {
  const newArticleId =
    articles.map((article) => article.id).reduce((a, b) => (a > b ? a : b)) + 1;
  const newArticle: Article = {
    id: newArticleId,
    title: request.body.title,
    body: request.body.body,
  };
  articles.push(newArticle);
  response.send(newArticle);
});

/**
 * PUT /api/articles/:id
 * 記事を編集
 */
app.put("/api/articles/:id", (request, response) => {
  const article = articles.find(
    (article) => article.id === parseInt(request.params.id)
  );
  if (!article) return response.status(404).send("Article not found.");
  article.title = request.body.title;
  article.body = request.body.body;
  response.send(article);
});

/**
 * DELETE /api/articles/:id
 * 記事を削除
 */
app.delete("/api/articles/:id", (request, response) => {
  const articleIndex = articles.findIndex(
    (article) => article.id === parseInt(request.params.id)
  );
  if (articleIndex === -1)
    return response.status(404).send("Article not found.");
  const article = articles[articleIndex];
  articles.splice(articleIndex, 1);
  response.send(article);
});

const port = process.env.PORT || 3000;
app.listen(port, () =>
  console.log(`SAMPLE REST API is listening on port ${port}.`)
);
